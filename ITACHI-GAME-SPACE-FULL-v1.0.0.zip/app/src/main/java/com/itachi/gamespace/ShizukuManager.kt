package com.itachi.gamespace

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object ShizukuManager {
    private const val REQUEST_CODE = 5001

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isRunning() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        if (!isRunning() || hasPermission()) return
        try { Shizuku.requestPermission(REQUEST_CODE) } catch (_: Throwable) {}
    }

    fun openManager(context: Context) {
        val intents = listOf(
            Intent().setClassName(
                "moe.shizuku.privileged.api",
                "moe.shizuku.manager.MainActivity"
            ),
            Intent("moe.shizuku.manager.action.MAIN")
        )
        for (intent in intents) {
            try {
                context.startActivity(intent)
                return
            } catch (_: Throwable) {}
        }
    }

    fun execute(command: String): Result<String> {
        if (!hasPermission()) return Result.failure(
            IllegalStateException("Shizuku permission is not granted")
        )
        return try {
            val process = Shizuku.newProcess(
                arrayOf("sh", "-c", command), null, null
            )
            val out = process.inputStream.bufferedReader().use { it.readText() }
            val err = process.errorStream.bufferedReader().use { it.readText() }
            val code = process.waitFor()
            if (code == 0) Result.success(out.trim())
            else Result.failure(IllegalStateException(err.ifBlank { "Command failed: $code" }))
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}
