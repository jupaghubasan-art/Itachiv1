package com.itachi.gamespace

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.view.Display

class DeviceMonitor(private val context: Context) {

    fun snapshot(display: Display?): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)

        val hz = display?.refreshRate ?: 0f
        val modes = display?.supportedModes?.map { it.refreshRate }
            ?.distinctBy { (it * 10).toInt() }
            ?.sorted()
            ?: emptyList()

        return DeviceSnapshot(
            model = Build.MODEL,
            manufacturer = Build.MANUFACTURER,
            android = Build.VERSION.RELEASE ?: "Unknown",
            sdk = Build.VERSION.SDK_INT,
            ramUsedMb = (mem.totalMem - mem.availMem) / 1048576,
            ramTotalMb = mem.totalMem / 1048576,
            refreshHz = hz,
            supportedHz = modes,
            thermal = thermal()
        )
    }

    fun monitor(display: Display?): MonitorSnapshot {
        val d = snapshot(display)
        return MonitorSnapshot(
            fps = null,
            hz = d.refreshHz,
            cpu = "Unavailable",
            gpu = "Unavailable",
            ramUsedMb = d.ramUsedMb,
            ramTotalMb = d.ramTotalMb,
            thermal = d.thermal
        )
    }

    private fun thermal(): String {
        if (Build.VERSION.SDK_INT < 29) return "Unavailable"
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return when (pm.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Normal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Light"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
            PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
            PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
            PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
            else -> "Unknown"
        }
    }
}
