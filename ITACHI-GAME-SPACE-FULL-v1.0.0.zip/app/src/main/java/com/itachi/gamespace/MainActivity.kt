package com.itachi.gamespace

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF08090D)
private val Card = Color(0xFF12141A)
private val Red = Color(0xFFE53935)
private val Blue = Color(0xFF4DA3FF)

class MainActivity : ComponentActivity() {
    private val monitor by lazy { DeviceMonitor(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }

    @Composable
    private fun App() {
        var intro by remember { mutableStateOf(true) }
        var shizuku by remember {
            mutableStateOf(ShizukuManager.isRunning() && ShizukuManager.hasPermission())
        }
        var tab by remember { mutableIntStateOf(0) }
        var boost by remember { mutableStateOf(BoostMode.BALANCED) }
        var touch by remember { mutableStateOf(TouchPreset.DEFAULT) }
        var color by remember { mutableStateOf(ColorPreset.NATURAL) }
        var dnd by remember { mutableStateOf(false) }
        var refresh by remember { mutableStateOf(monitor.snapshot(display).refreshHz) }

        LaunchedEffect(Unit) {
            delay(4500)
            intro = false
        }

        LaunchedEffect(Unit) {
            while (true) {
                shizuku = ShizukuManager.isRunning() && ShizukuManager.hasPermission()
                refresh = monitor.snapshot(display).refreshHz
                delay(1500)
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Red,
                secondary = Blue,
                background = Bg,
                surface = Card
            )
        ) {
            if (intro) {
                IntroScreen(onSkip = { intro = false })
            } else {
                MainScreen(
                    shizuku = shizuku,
                    tab = tab,
                    onTab = { tab = it },
                    boost = boost,
                    onBoost = { boost = it },
                    touch = touch,
                    onTouch = { touch = it },
                    color = color,
                    onColor = { color = it },
                    dnd = dnd,
                    onDnd = { dnd = it },
                    refresh = refresh,
                    onShizuku = {
                        if (!ShizukuManager.isRunning()) {
                            ShizukuManager.openManager(this@MainActivity)
                        } else {
                            ShizukuManager.requestPermission()
                        }
                    },
                    onLaunch = { launchMlbb() },
                    onOverlay = { openOverlay() }
                )
            }
        }
    }

    private fun launchMlbb() {
        val pkg = GameDetector.installedPackage(this) ?: "com.mobile.legends"
        packageManager.getLaunchIntentForPackage(pkg)?.let { startActivity(it) }
    }

    private fun openOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } else {
            startService(Intent(this, FloatingPanelService::class.java))
        }
    }

    @Composable
    private fun IntroScreen(onSkip: () -> Unit) {
        Box(
            Modifier.fillMaxSize().background(Bg),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("月", color = Red, fontSize = 62.sp)
                Spacer(Modifier.height(12.dp))
                Text("ITACHI", color = Color.White, fontSize = 30.sp)
                Text("GAME SPACE", color = Red, fontSize = 18.sp)
                Spacer(Modifier.height(26.dp))
                CircularProgressIndicator(color = Red)
                Spacer(Modifier.height(22.dp))
                TextButton(onClick = onSkip) { Text("SKIP") }
            }
        }
    }

    @Composable
    private fun MainScreen(
        shizuku: Boolean,
        tab: Int,
        onTab: (Int) -> Unit,
        boost: BoostMode,
        onBoost: (BoostMode) -> Unit,
        touch: TouchPreset,
        onTouch: (TouchPreset) -> Unit,
        color: ColorPreset,
        onColor: (ColorPreset) -> Unit,
        dnd: Boolean,
        onDnd: (Boolean) -> Unit,
        refresh: Float,
        onShizuku: () -> Unit,
        onLaunch: () -> Unit,
        onOverlay: () -> Unit
    ) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("ITACHI GAME SPACE", color = Red, fontSize = 27.sp)
                Text("REAL SYSTEM CONTROL • NO FAKE BOOST", color = Color.Gray, fontSize = 11.sp)

                StatusCard(shizuku, onShizuku)

                when (tab) {
                    0 -> HomeTab(refresh, onLaunch, onOverlay)
                    1 -> MonitorTab(refresh)
                    2 -> ControlsTab(boost, onBoost, touch, onTouch, color, onColor, dnd, onDnd)
                    else -> SettingsTab()
                }
            }

            NavigationBar(containerColor = Card) {
                listOf("HOME", "MONITOR", "BOOST", "SETTINGS").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { onTab(i) },
                        icon = {},
                        label = { Text(label, fontSize = 9.sp) }
                    )
                }
            }
        }
    }

    @Composable
    private fun StatusCard(ok: Boolean, onClick: () -> Unit) {
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (ok) "✓ SHIZUKU CONNECTED" else "✕ SHIZUKU REQUIRED",
                        color = if (ok) Color(0xFF72FF8A) else Red)
                    Text(
                        if (ok) "Privileged features are available."
                        else "Start Shizuku and grant this app permission.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
                if (!ok) Button(onClick = onClick) { Text("SETUP") }
            }
        }
    }

    @Composable
    private fun HomeTab(hz: Float, launch: () -> Unit, overlay: () -> Unit) {
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(18.dp)) {
                Text("MOBILE LEGENDS: BANG BANG", fontSize = 18.sp)
                Text("Game profile • ready", color = Color.Gray)
                Spacer(Modifier.height(14.dp))
                Text("DISPLAY  ${"%.1f".format(hz)} Hz")
                Text("FPS       Unavailable")
                Text("CPU/GPU   Unavailable")
                Spacer(Modifier.height(14.dp))
                Button(onClick = launch, Modifier.fillMaxWidth()) { Text("LAUNCH MLBB") }
                OutlinedButton(onClick = overlay, Modifier.fillMaxWidth()) {
                    Text("FLOATING PANEL")
                }
            }
        }
    }

    @Composable
    private fun MonitorTab(hz: Float) {
        MetricCard("LIVE MONITOR") {
            Metric("FPS", "Unavailable")
            Metric("DISPLAY", "${"%.1f".format(hz)} Hz")
            Metric("CPU", "Unavailable")
            Metric("GPU", "Unavailable")
            Metric("RAM", "Live")
            Metric("THERMAL", "Live")
            Spacer(Modifier.height(8.dp))
            Text("FPS is shown as unavailable until a reliable, non-invasive measurement source is implemented.", color=Color.Gray, fontSize=11.sp)
        }
    }

    @Composable
    private fun ControlsTab(
        boost: BoostMode,
        onBoost: (BoostMode) -> Unit,
        touch: TouchPreset,
        onTouch: (TouchPreset) -> Unit,
        color: ColorPreset,
        onColor: (ColorPreset) -> Unit,
        dnd: Boolean,
        onDnd: (Boolean) -> Unit
    ) {
        MetricCard("PERFORMANCE MODE") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                BoostMode.values().forEach { b ->
                    FilterChip(selected = boost == b, onClick = { onBoost(b) }, label = { Text(b.name) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("TOUCH RESPONSE")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TouchPreset.values().forEach { t ->
                    FilterChip(selected = touch == t, onClick = { onTouch(t) }, label = { Text(t.name) })
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("GAME COLOR")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(ColorPreset.NATURAL, ColorPreset.VIVID, ColorPreset.CINEMATIC, ColorPreset.GRAYSCALE)
                    .forEach { c ->
                        FilterChip(selected = color == c, onClick = { onColor(c) }, label = { Text(c.name) })
                    }
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DND / GAMING", Modifier.weight(1f))
                Switch(checked = dnd, onCheckedChange = onDnd)
            }
            Text("Selections are stored as preferences; device-specific system actions are only applied when supported.", color=Color.Gray, fontSize=11.sp)
        }
    }

    @Composable
    private fun SettingsTab() {
        MetricCard("SETTINGS") {
            Text("Opening animation: 4.5 seconds")
            Text("Animated background: optional")
            Text("Root: not required")
            Text("Shizuku: required")
            Text("MLBB memory/file modification: disabled")
            Spacer(Modifier.height(10.dp))
            Text("Unsupported controls must remain unavailable rather than pretending to work.", color=Color.Gray, fontSize=11.sp)
        }
    }

    @Composable
    private fun MetricCard(title: String, content: @Composable ColumnScope.() -> Unit) {
        Card(colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(18.dp), content = {
                Text(title, color = Red, fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                content()
            })
        }
    }

    @Composable
    private fun Metric(name: String, value: String) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
            Text(name, Modifier.weight(1f))
            Text(value, color = Blue)
        }
    }
}
