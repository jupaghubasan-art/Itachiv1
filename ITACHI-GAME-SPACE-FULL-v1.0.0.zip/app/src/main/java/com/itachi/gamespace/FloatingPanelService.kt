package com.itachi.gamespace

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView

class FloatingPanelService : Service() {
    private var wm: WindowManager? = null
    private var root: View? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }

        val channelId = "itachi_game"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "ITACHI Game Session", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("ITACHI GAME SPACE")
            .setContentText("Gaming monitor active")
            .setOngoing(true)
            .build()

        try { startForeground(1001, notification) } catch (_: Throwable) {}

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 16, 20, 16)
            setBackgroundColor(0xE615151B.toInt())
        }

        val title = TextView(this).apply {
            text = "ITACHI GAME SPACE"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        val stats = TextView(this).apply {
            text = "FPS  --   HZ  --\nCPU  Unavailable\nGPU  Unavailable\nRAM  --\nTEMP --"
            textSize = 12f
            setTextColor(0xFFE5E5E5.toInt())
        }
        box.addView(title)
        box.addView(stats)

        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

        val lp = WindowManager.LayoutParams(
            330, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 20
        lp.y = 120

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        root = box
        try { wm?.addView(box, lp) } catch (_: Throwable) { stopSelf() }
    }

    override fun onDestroy() {
        try { root?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
