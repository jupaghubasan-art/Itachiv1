package com.itachi.gamespace

import android.content.Context

object GameDetector {
    private val candidates = listOf(
        "com.mobile.legends",
        "com.mobile.legends.mi",
        "com.mobile.legends.hwag"
    )

    fun installedPackage(context: Context): String? {
        val pm = context.packageManager
        return candidates.firstOrNull {
            try { pm.getLaunchIntentForPackage(it) != null } catch (_: Throwable) { false }
        }
    }
}
