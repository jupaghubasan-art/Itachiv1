package com.itachi.gamespace

data class DeviceSnapshot(
    val model: String,
    val manufacturer: String,
    val android: String,
    val sdk: Int,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val refreshHz: Float,
    val supportedHz: List<Float>,
    val thermal: String
)

data class MonitorSnapshot(
    val fps: Float?,
    val hz: Float,
    val cpu: String,
    val gpu: String,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val thermal: String
)

enum class BoostMode { BATTERY, BALANCED, PERFORMANCE }
enum class TouchPreset { SLOW, DEFAULT, FAST }
enum class ColorPreset { NATURAL, COOL, WARM, VIVID, CINEMATIC, GRAYSCALE, CUSTOM }
