# ITACHI GAME SPACE

A fresh-from-zero Android Game Space project.

## What is already included

- Kotlin + native Android/Jetpack Compose
- GitHub Actions build workflow
- Shizuku API integration
- Shizuku connection and permission state
- 4.5 second skippable opening screen
- Game Space home
- MLBB package detection/launch
- Floating overlay service
- Real display refresh-rate reading
- Supported display-mode discovery
- RAM monitoring
- Android thermal status where exposed
- Performance/touch/color/DND UI
- Honest "Unavailable" states for metrics that cannot safely be measured yet
- No root requirement
- No MLBB process injection
- No MLBB file modification
- No anti-cheat bypass
- No fake 120 FPS claim

## Build on GitHub

1. Create a new GitHub repository.
2. Upload the entire contents of this folder.
3. Commit to `main`.
4. Open the **Actions** tab.
5. Select **Build ITACHI GAME SPACE**.
6. Run **workflow_dispatch**, or push to main.
7. Wait for the build.
8. Open the completed workflow run.
9. Download the artifact named `ITACHI-GAME-SPACE-debug`.
10. Extract it and install `app-debug.apk`.

## Shizuku

Install and start Shizuku separately, then grant ITACHI GAME SPACE permission.

Official Shizuku:
https://github.com/RikkaApps/Shizuku

Official Shizuku API:
https://github.com/RikkaApps/Shizuku-API

The project uses `dev.rikka.shizuku:api:12.2.0`.

## Important technical limitations

Android does not guarantee that an ordinary app can read GPU utilization, MLBB's private FPS, touch sampling rate, or change another app's rendering pipeline.

Therefore:
- unsupported metrics are displayed as unavailable;
- display Hz is kept separate from game FPS;
- no fake FPS value is generated;
- color controls do not claim to modify MLBB unless a supported system-level mechanism is actually implemented;
- touch presets do not claim to change physical touch sampling unless the device exposes a supported control.

## Next device-specific work

The foundation is ready for adding:
- Shizuku-backed supported system commands after capability testing;
- real session FPS/frame-time measurement where a reliable source exists;
- supported refresh-mode selection;
- DND permission flow;
- temporary setting restore;
- benchmark/session report;
- animated Itachi background;
- polished draggable floating panel.
